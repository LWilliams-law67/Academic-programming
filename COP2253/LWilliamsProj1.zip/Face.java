/**
   COP2253 Java programming
   This program prints the face of a bear to the console using
   the , . ' ` @ ? ( ) / | characters.
   
   @author lwilliams
   @version 1.0
   
   COP2253 project 1
   filename: Face.java
*/

public class Face
{
   public static void main(String [] args)
   {
      System.out.println(" .'`'.        ___,,,___        '``");
      System.out.println(" : (   `.''````         ````''-   ) ;");
      System.out.println(" :                            `.   .'");
      System.out.println("  `.                            :.'");
      System.out.println("    /       __?        __?      |");
      System.out.println();
      System.out.println("   |        (@)       (@)        |");
      System.out.println("   |         |         |         |");
      System.out.println("   |       /             |       |");
      System.out.println("    |     |      .-.      |     /");
      System.out.println("     `.   | . . |   | . . |   .`");
      System.out.println("       `-._|.'.(     ).'./_.-'");
      System.out.println("           `|'  `._.'  '/'");
      System.out.println("             ` -- -- .'");
      System.out.println("               `-...-'");
   }
}