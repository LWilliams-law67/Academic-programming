/*
 *      File  : transaction.cpp
 *      Author: Luke Williams (law67)
 *      Course: COP3014
 *      Proj  : Project 03
 *      Descr : The definition of the class that contains the initialized members
 *              of transactions for adding and removing from the summary for the day.
 */
 
 #include "transaction.h"
 #include <iostream>
 
 using namespace std;
 
 //transaction(){
 	
// }
